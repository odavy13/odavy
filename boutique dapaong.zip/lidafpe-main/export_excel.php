<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$boutique_id = $_SESSION['boutique_id'] ?? null;

// Pour le directeur : filtrage par boutique
if ($role == 'directeur' && isset($_GET['boutique_id']) && is_numeric($_GET['boutique_id'])) {
    $boutique_id = intval($_GET['boutique_id']);
}

// Récupérer le stock
$stock_query = "SELECT p.nom AS Produit, b.nom AS Boutique, p.quantite AS Quantité, p.unite AS Unité
                FROM produits p
                JOIN boutiques b ON p.boutique_id = b.id";
if ($role != 'directeur' || $boutique_id) $stock_query .= " WHERE p.boutique_id = $boutique_id";
$result_stock = $conn->query($stock_query);

// Récupérer ventes
$vente_query = "SELECT v.id AS 'ID Vente', b.nom AS Boutique, u.nom AS Vendeur, v.total AS Total, v.created_at AS Date
                FROM ventes v
                JOIN utilisateurs u ON v.utilisateur_id = u.id
                JOIN boutiques b ON v.boutique_id = b.id";
if ($role != 'directeur' || $boutique_id) $vente_query .= " WHERE v.boutique_id = $boutique_id";
$vente_query .= " ORDER BY v.created_at DESC";
$result_ventes = $conn->query($vente_query);

// Récupérer pertes
$pertes_query = "SELECT p.nom AS Produit, b.nom AS Boutique, pp.type_perte AS 'Type perte', pp.quantite AS Quantité, pp.date_perte AS Date
                 FROM pertes_produits pp
                 JOIN produits p ON pp.produit_id = p.id
                 JOIN boutiques b ON pp.boutique_id = b.id";
if ($role != 'directeur' || $boutique_id) $pertes_query .= " WHERE pp.boutique_id = $boutique_id";
$pertes_query .= " ORDER BY pp.date_perte DESC";
$result_pertes = $conn->query($pertes_query);

// Si le paramètre download est présent, générer le fichier Excel
if (isset($_GET['download'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=export_lidafpe.xls");

    // STOCK
    echo "STOCK\n";
    echo "Produit\tBoutique\tQuantité\tUnité\n";
    while ($row = $result_stock->fetch_assoc()) {
        echo implode("\t", $row) . "\n";
    }

    echo "\nVENTES\n";
    echo "ID Vente\tBoutique\tVendeur\tTotal\tDate\n";
    while ($row = $result_ventes->fetch_assoc()) {
        echo implode("\t", $row) . "\n";
    }

    echo "\nPERTE PRODUITS\n";
    echo "Produit\tBoutique\tType perte\tQuantité\tDate\n";
    while ($row = $result_pertes->fetch_assoc()) {
        echo implode("\t", $row) . "\n";
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Export Excel - LIDAF-PE</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Export Excel - LIDAF-PE</h2>
    <p>Vous pouvez télécharger les données actuelles (Stock, Ventes, Produits cassés/expirés) au format Excel :</p>
    <a href="export_excel.php?download=1<?php echo ($boutique_id ? '&boutique_id='.$boutique_id : ''); ?>" class="btn btn-success">
        <i class="fa-solid fa-file-excel"></i> Télécharger Excel
    </a>
    <hr>

    <h4>Stock actuel</h4>
    <table class="table table-striped table-bordered">
        <thead>
            <tr><th>Produit</th><th>Boutique</th><th>Quantité</th><th>Unité</th></tr>
        </thead>
        <tbody>
            <?php while ($row = $result_stock->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['Produit']); ?></td>
                    <td><?php echo htmlspecialchars($row['Boutique']); ?></td>
                    <td><?php echo $row['Quantité']; ?></td>
                    <td><?php echo htmlspecialchars($row['Unité']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h4>Ventes récentes</h4>
    <table class="table table-striped table-bordered">
        <thead>
            <tr><th>ID Vente</th><th>Boutique</th><th>Vendeur</th><th>Total</th><th>Date</th></tr>
        </thead>
        <tbody>
            <?php while ($row = $result_ventes->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['ID Vente']; ?></td>
                    <td><?php echo $row['Boutique']; ?></td>
                    <td><?php echo $row['Vendeur']; ?></td>
                    <td><?php echo $row['Total']; ?></td>
                    <td><?php echo $row['Date']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h4>Produits cassés / expirés</h4>
    <table class="table table-striped table-bordered">
        <thead>
            <tr><th>Produit</th><th>Boutique</th><th>Type perte</th><th>Quantité</th><th>Date</th></tr>
        </thead>
        <tbody>
            <?php while ($row = $result_pertes->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['Produit']; ?></td>
                    <td><?php echo $row['Boutique']; ?></td>
                    <td><?php echo $row['Type perte']; ?></td>
                    <td><?php echo $row['Quantité']; ?></td>
                    <td><?php echo $row['Date']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary mt-3">Retour au Dashboard</a>
</div>
</body>
</html>
