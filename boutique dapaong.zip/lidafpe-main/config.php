<?php

if ($_SERVER['HTTP_HOST'] == "localhost") {
    $servername = "localhost";
    $username   = "root";
    $password   = "";
    $dbname     = "lidafpe_db";
} else {
    $servername = "sql107.infinityfree.com";
    $username   = "if0_41192478";
    $password   = "fF5bXuNOZ7g6";
    $dbname     = "if0_41192478_XXX";
}

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
