<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$boutique_id = $_SESSION['boutique_id'] ?? null;

// Filtrage boutique pour le directeur
if ($role == 'directeur') {
    if (isset($_GET['boutique_id']) && is_numeric($_GET['boutique_id'])) {
        $boutique_id = intval($_GET['boutique_id']);
    } else {
        $boutique_id = null; // toutes boutiques
    }
}

// Récupérer le stock
$stock_query = "SELECT p.*, b.nom AS boutique_nom
    FROM produits p
    JOIN boutiques b ON p.boutique_id = b.id";

if ($role != 'directeur' && $boutique_id) {
    $stock_query .= " WHERE p.boutique_id = $boutique_id";
} elseif ($role == 'directeur' && $boutique_id) {
    $stock_query .= " WHERE p.boutique_id = $boutique_id";
}

$result_stock = $conn->query($stock_query);

// Récupérer les ventes
$vente_query = "SELECT v.id, v.total, v.created_at, u.nom AS vendeur, b.nom AS boutique
    FROM ventes v
    JOIN utilisateurs u ON v.utilisateur_id = u.id
    JOIN boutiques b ON v.boutique_id = b.id";

if ($role != 'directeur' && $boutique_id) {
    $vente_query .= " WHERE v.boutique_id = $boutique_id";
} elseif ($role == 'directeur' && $boutique_id) {
    $vente_query .= " WHERE v.boutique_id = $boutique_id";
}

$vente_query .= " ORDER BY v.created_at DESC";
$result_ventes = $conn->query($vente_query);

// Récupérer pertes
$pertes_query = "SELECT pp.*, p.nom AS produit_nom, b.nom AS boutique_nom
    FROM pertes_produits pp
    JOIN produits p ON pp.produit_id = p.id
    JOIN boutiques b ON pp.boutique_id = b.id";

if ($role != 'directeur' && $boutique_id) {
    $pertes_query .= " WHERE pp.boutique_id = $boutique_id";
} elseif ($role == 'directeur' && $boutique_id) {
    $pertes_query .= " WHERE pp.boutique_id = $boutique_id";
}

$pertes_query .= " ORDER BY pp.date_perte DESC";
$result_pertes = $conn->query($pertes_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - LIDAF-PE</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background-color: #f4f6f9; }
        .card { border-radius: 15px; }
        .sidebar {
            background: #1e293b;
            min-height: 100vh;
            color: white;
            padding: 20px;
        }
        .sidebar a {
            color: #cbd5e1;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
        }
        .sidebar a:hover {
            color: white;
        }
        .table thead {
            background-color: #0d6efd;
            color: white;
        }
    </style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- Sidebar -->
<div class="col-md-2 sidebar">
    <h4>LIDAF-PE</h4>
    <hr>
    <?php if($role == 'directeur'): ?>
        <a href="ajouter_boutique.php">Ajouter boutique</a>
        <a href="ajouter_produit.php">Ajouter produit</a>
        <a href="export_excel.php">Exporter Excel</a>
    <?php endif; ?>
    <a href="enregistrer_vente.php">Nouvelle vente</a>
    <a href="enregistrer_perte.php">Enregistrer perte</a>
    <a href="logout.php" class="text-danger">Déconnexion</a>
</div>

<!-- Main content -->
<div class="col-md-10 p-4">

<h2 class="mb-4">Tableau de Bord</h2>

<!-- Statistiques rapides -->
<?php
$totalProduits = $conn->query("SELECT COUNT(*) as total FROM produits")->fetch_assoc()['total'];
$totalVentes = $conn->query("SELECT COUNT(*) as total FROM ventes")->fetch_assoc()['total'];
$totalBoutiques = $conn->query("SELECT COUNT(*) as total FROM boutiques")->fetch_assoc()['total'];
?>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                <h5>Produits</h5>
                <h3><?= $totalProduits ?></h3>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-success text-white shadow">
            <div class="card-body">
                <h5>Ventes</h5>
                <h3><?= $totalVentes ?></h3>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-warning text-white shadow">
            <div class="card-body">
                <h5>Boutiques</h5>
                <h3><?= $totalBoutiques ?></h3>
            </div>
        </div>
    </div>
</div>

<!-- Filtre directeur -->
<?php if($role == 'directeur'): ?>
<div class="mb-3">
    <label><strong>Filtrer par boutique :</strong></label>
    <div>
        <?php
        $boutiques = $conn->query("SELECT * FROM boutiques ORDER BY nom ASC");
        while($b = $boutiques->fetch_assoc()) {
            echo "<a class='btn btn-outline-primary btn-sm me-2 mb-2' href='dashboard.php?boutique_id=".$b['id']."'>".$b['nom']."</a>";
        }
        ?>
        <a class="btn btn-secondary btn-sm" href='dashboard.php'>Toutes</a>
    </div>
</div>
<?php endif; ?>

<!-- STOCK -->
<h4 class="mt-4">Stock actuel</h4>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<thead>
<tr>
    <th>Produit</th>
    <th>Boutique</th>
    <th>Quantité</th>
    <th>Unité</th>
    <th>Alerte</th>
</tr>
</thead>
<tbody>
<?php while($row = $result_stock->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($row['nom']) ?></td>
    <td><?= htmlspecialchars($row['boutique_nom']) ?></td>
    <td><?= $row['quantite'] ?></td>
    <td><?= htmlspecialchars($row['unite']) ?></td>
    <td>
        <?php
        if ($row['quantite'] <= 5) {
            echo "<span class='badge bg-danger'>Stock faible</span>";
        } else {
            echo "<span class='badge bg-success'>OK</span>";
        }
        ?>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<!-- VENTES -->
<h4 class="mt-4">Ventes</h4>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<thead>
<tr>
    <th>ID</th>
    <th>Boutique</th>
    <th>Vendeur</th>
    <th>Total</th>
    <th>Date</th>
</tr>
</thead>
<tbody>
<?php while($row = $result_ventes->fetch_assoc()): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['boutique'] ?></td>
    <td><?= $row['vendeur'] ?></td>
    <td><?= number_format($row['total']) ?> FCFA</td>
    <td><?= $row['created_at'] ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<!-- PERTES -->
<h4 class="mt-4">Produits cassés / expirés</h4>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<thead>
<tr>
    <th>Produit</th>
    <th>Boutique</th>
    <th>Type</th>
    <th>Quantité</th>
    <th>Date</th>
</tr>
</thead>
<tbody>
<?php while($row = $result_pertes->fetch_assoc()): ?>
<tr>
    <td><?= $row['produit_nom'] ?></td>
    <td><?= $row['boutique_nom'] ?></td>
    <td><?= $row['type_perte'] ?></td>
    <td><?= $row['quantite'] ?></td>
    <td><?= $row['date_perte'] ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

</div>
</div>
</div>

</body>
</html>
