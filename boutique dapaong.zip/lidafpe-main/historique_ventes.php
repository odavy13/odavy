<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Déterminer la boutique
$boutique_id = $_SESSION['boutique_id'] ?? null;

// Pour le directeur : possibilité de filtrer ou voir toutes les boutiques
if ($_SESSION['role'] == 'directeur') {
    if (isset($_GET['boutique_id']) && is_numeric($_GET['boutique_id'])) {
        $boutique_id = intval($_GET['boutique_id']);
        $stmt = $conn->prepare("
            SELECT v.id, v.total, v.created_at, u.nom AS vendeur, b.nom AS boutique
            FROM ventes v
            JOIN utilisateurs u ON v.utilisateur_id = u.id
            JOIN boutiques b ON v.boutique_id = b.id
            WHERE v.boutique_id = ?
            ORDER BY v.created_at DESC
        ");
        $stmt->bind_param("i", $boutique_id);
    } else {
        // Toutes les boutiques
        $stmt = $conn->prepare("
            SELECT v.id, v.total, v.created_at, u.nom AS vendeur, b.nom AS boutique
            FROM ventes v
            JOIN utilisateurs u ON v.utilisateur_id = u.id
            JOIN boutiques b ON v.boutique_id = b.id
            ORDER BY v.created_at DESC
        ");
    }
} else {
    // Gérant : voir uniquement sa boutique
    $stmt = $conn->prepare("
        SELECT v.id, v.total, v.created_at, u.nom AS vendeur, b.nom AS boutique
        FROM ventes v
        JOIN utilisateurs u ON v.utilisateur_id = u.id
        JOIN boutiques b ON v.boutique_id = b.id
        WHERE v.boutique_id = ?
        ORDER BY v.created_at DESC
    ");
    $stmt->bind_param("i", $boutique_id);
}

$stmt->execute();
$result_ventes = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Historique des ventes - LIDAF-PE</title>
</head>
<body>

<h2>Historique des ventes</h2>

<?php if ($_SESSION['role'] == 'directeur'): ?>
    <h4>Filtrer par boutique :</h4>
    <ul>
    <?php
    $boutiques = $conn->query("SELECT * FROM boutiques");
    while($b = $boutiques->fetch_assoc()) {
        echo "<li><a href='historique_ventes.php?boutique_id=".$b['id']."'>".$b['nom']."</a></li>";
    }
    ?>
    <li><a href='historique_ventes.php'>Toutes les boutiques</a></li>
    </ul>
<?php endif; ?>

<table border="1" cellpadding="5">
    <tr>
        <th>ID Vente</th>
        <th>Boutique</th>
        <th>Vendeur</th>
        <th>Total</th>
        <th>Date</th>
    </tr>
    <?php if ($result_ventes->num_rows > 0): ?>
        <?php while($row = $result_ventes->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['boutique']; ?></td>
            <td><?php echo $row['vendeur']; ?></td>
            <td><?php echo $row['total']; ?></td>
            <td><?php echo $row['created_at']; ?></td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="5" style="text-align:center;">Aucune vente enregistrée</td>
        </tr>
    <?php endif; ?>
</table>

<br>
<a href="dashboard.php">Retour</a>
<?php
// Lien export Excel
$export_link = 'export_ventes.php';
if (isset($boutique_id)) $export_link .= '?boutique_id=' . $boutique_id;
?>
<a href="<?php echo $export_link; ?>">Exporter en Excel</a>

</body>
</html>
