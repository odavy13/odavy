<?php
session_start();
include("config.php");

// Vérifier que l'utilisateur est connecté et a le rôle correct
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'gerant' && $_SESSION['role'] != 'vendeur')) {
    header("Location: login.php");
    exit();
}

$boutique_id = $_SESSION['boutique_id'];

// Récupérer les produits disponibles dans la boutique
$result_produits = $conn->query("SELECT * FROM produits WHERE boutique_id = $boutique_id");

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (!empty($_POST['produit']) && !empty($_POST['quantite'])) {

        $produits = $_POST['produit'];
        $quantites = $_POST['quantite'];

        $vente_valide = false;
        foreach ($quantites as $q) {
            if (floatval($q) > 0) {
                $vente_valide = true;
                break;
            }
        }

        if (!$vente_valide) {
            $error = "Veuillez entrer au moins une quantité supérieure à 0.";
        } else {

            $total = 0;
            $stock_ok = true;

            foreach ($produits as $index => $produit_id) {

                $q = floatval($quantites[$index]);
                if ($q <= 0) continue;

                $res = $conn->query("SELECT prix_vente, quantite FROM produits WHERE id=$produit_id");
                $row = $res->fetch_assoc();

                if ($q > $row['quantite']) {
                    $stock_ok = false;
                    $error = "Stock insuffisant pour le produit ID $produit_id.";
                    break;
                }

                $total += $row['prix_vente'] * $q;
            }

            if ($stock_ok) {

                // Enregistrer la vente
                $stmt = $conn->prepare("INSERT INTO ventes (utilisateur_id, boutique_id, total) VALUES (?, ?, ?)");
                $stmt->bind_param("iid", $_SESSION['user_id'], $boutique_id, $total);
                $stmt->execute();
                $vente_id = $stmt->insert_id;

                foreach ($produits as $index => $produit_id) {

                    $q = floatval($quantites[$index]);
                    if ($q <= 0) continue;

                    $res = $conn->query("SELECT prix_vente, quantite FROM produits WHERE id=$produit_id");
                    $row = $res->fetch_assoc();
                    $prix_unitaire = $row['prix_vente'];

                    // Enregistrer détails
                    $stmt2 = $conn->prepare("INSERT INTO details_vente (vente_id, produit_id, quantite, prix_unitaire) VALUES (?, ?, ?, ?)");
                    $stmt2->bind_param("iiid", $vente_id, $produit_id, $q, $prix_unitaire);
                    $stmt2->execute();

                    // Mise à jour stock
                    $nouveau_stock = $row['quantite'] - $q;
                    $conn->query("UPDATE produits SET quantite=$nouveau_stock WHERE id=$produit_id");
                }

                $success = "Vente enregistrée avec succès ! Total : " . number_format($total, 2) . " FCFA";

                // Recharger produits
                $result_produits = $conn->query("SELECT * FROM produits WHERE boutique_id = $boutique_id");
            }
        }
    } else {
        $error = "Aucun produit sélectionné.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Enregistrer Vente - LIDAF-PE</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Inter',sans-serif; background:#f5f7fa; margin:0; padding:20px;}
h2 { color:#333; }
.card { background: rgba(255,255,255,0.05); padding:20px; border-radius:15px; backdrop-filter: blur(10px); box-shadow:0 10px 20px rgba(0,0,0,0.2); max-width:1200px; margin:auto; }
table { width:100%; border-collapse: collapse; margin-bottom:20px; }
th, td { border:1px solid #ccc; padding:10px; text-align:left; }
th { background:#f2f2f2; }
input[type=number] { width:80px; padding:5px; border-radius:5px; border:1px solid #ccc; }
button { padding:10px 20px; background:#6366f1; color:white; border:none; border-radius:5px; cursor:pointer; font-size:16px; }
button:hover { background:#4f46e5; }
.success { background:rgba(0,255,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; }
.error { background:rgba(255,0,0,0.2); padding:12px; border-radius:8px; margin-bottom:15px; }
.total { font-weight:bold; color:#111; }
a.return { display:inline-block; margin-top:15px; color:#6366f1; text-decoration:none; }
a.return:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="card">
<h2><i class="fa-solid fa-cash-register"></i> Enregistrer une vente</h2>

<?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>
<?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>

<form method="POST">
<table>
<tr>
<th>Produit</th>
<th>Stock</th>
<th>Quantité</th>
</tr>

<?php while($row = $result_produits->fetch_assoc()): ?>
<tr>
<td><strong><?php echo htmlspecialchars($row['nom']); ?></strong><br>
<small><?php echo number_format($row['prix_vente'],2); ?> FCFA</small></td>
<td><?php echo $row['quantite'] . " " . htmlspecialchars($row['unite']); ?></td>
<td>
<input type="number" step="0.01" min="0" max="<?php echo $row['quantite']; ?>" value="0" name="quantite[]" class="quantite-input">
<input type="hidden" name="produit[]" value="<?php echo $row['id']; ?>">
<input type="hidden" class="prix-produit" value="<?php echo $row['prix_vente']; ?>">
</td>
</tr>
<?php endwhile; ?>
</table>

<div style="display:flex; justify-content:space-between; align-items:center;">
<h3 class="total">Total estimé : <span id="totalDisplay">0</span> FCFA</h3>
<button type="submit"><i class="fa-solid fa-check"></i> Valider la vente</button>
</div>
</form>

<a href="dashboard.php" class="return"><i class="fa-solid fa-arrow-left"></i> Retour</a>
</div>

<script>
// Vérification qu'au moins une quantité > 0
document.querySelector("form").addEventListener("submit", function(e){
    let quantites = document.querySelectorAll('.quantite-input');
    let valide = false;
    quantites.forEach(q => { if(parseFloat(q.value) > 0) valide = true; });
    if(!valide){ alert("Veuillez entrer au moins une quantité supérieure à 0"); e.preventDefault(); }
});

// Calcul total dynamique
const inputs = document.querySelectorAll('.quantite-input');
const prix = document.querySelectorAll('.prix-produit');
const totalDisplay = document.getElementById('totalDisplay');

inputs.forEach((input,index)=>{
    input.addEventListener("input", ()=>{
        let total=0;
        inputs.forEach((q,i)=>{ total += parseFloat(q.value||0) * parseFloat(prix[i].value); });
        totalDisplay.textContent = total.toFixed(2);
    });
});
</script>

</body>
</html>
