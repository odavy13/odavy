<?php
session_start();
include("config.php");

// Vérification de connexion et rôle
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'gerant' && $_SESSION['role'] != 'directeur')) {
    header("Location: login.php");
    exit();
}

// Récupérer l'ID de la boutique depuis la session
$boutique_id = isset($_SESSION['boutique_id']) ? intval($_SESSION['boutique_id']) : 0;

// Vérifier que la boutique est valide
if ($boutique_id <= 0) {
    die("Erreur : Boutique non définie.");
}

// Récupérer les produits de la boutique
$result_produits = $conn->query("SELECT * FROM produits WHERE boutique_id = $boutique_id");

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $produit_id = isset($_POST['produit']) ? intval($_POST['produit']) : 0;
    $quantite = isset($_POST['quantite']) ? floatval($_POST['quantite']) : 0;
    $type_perte = isset($_POST['type_perte']) ? $_POST['type_perte'] : '';

    if ($produit_id > 0 && $quantite > 0 && in_array($type_perte, ['cassé','expiré'])) {

        $res_stock = $conn->query("SELECT quantite FROM produits WHERE id=$produit_id AND boutique_id=$boutique_id");
        $row_stock = $res_stock->fetch_assoc();

        if (!$row_stock) {
            $error = "Produit introuvable dans cette boutique.";
        } elseif ($quantite > $row_stock['quantite']) {
            $error = "Quantité supérieure au stock disponible.";
        } else {
            $stmt = $conn->prepare("INSERT INTO pertes_produits (produit_id, boutique_id, type_perte, quantite) VALUES (?,?,?,?)");
            $stmt->bind_param("iisd", $produit_id, $boutique_id, $type_perte, $quantite);
            $stmt->execute();

            $conn->query("UPDATE produits SET quantite = quantite - $quantite WHERE id=$produit_id");

            $success = "Perte enregistrée avec succès.";
            $result_produits = $conn->query("SELECT * FROM produits WHERE boutique_id = $boutique_id"); // reload produits
        }

    } else {
        $error = "Veuillez remplir tous les champs correctement.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Enregistrer Perte - LIDAF-PE</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Inter',sans-serif; background:#f5f7fa; margin:0; padding:20px; }
.card { max-width:600px; margin:auto; padding:25px; border-radius:15px; background:rgba(255,255,255,0.05); backdrop-filter: blur(10px); box-shadow:0 10px 20px rgba(0,0,0,0.2);}
h2 { color:#333; margin-bottom:20px; }
label { display:block; margin-top:15px; font-weight:600; }
select, input, button { width:100%; padding:10px; margin-top:5px; border-radius:6px; border:1px solid #ccc; font-size:14px; }
button { background:#6366f1; color:white; border:none; cursor:pointer; transition:0.3s; }
button:hover { background:#4f46e5; }
.success { background:rgba(0,255,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; }
.error { background:rgba(255,0,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; }
a.return { display:inline-block; margin-top:15px; color:#6366f1; text-decoration:none; }
a.return:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="card">
<h2><i class="fa-solid fa-box-open"></i> Enregistrer une perte</h2>

<?php if(isset($success)) echo "<div class='success'><i class='fa-solid fa-check'></i> $success</div>"; ?>
<?php if(isset($error)) echo "<div class='error'><i class='fa-solid fa-triangle-exclamation'></i> $error</div>"; ?>

<form method="POST">
    <label>Produit :</label>
    <select name="produit" required>
        <option value="">--Choisir--</option>
        <?php while($row = $result_produits->fetch_assoc()): ?>
            <option value="<?php echo $row['id']; ?>">
                <?php echo $row['nom'] . " (Stock: ".$row['quantite']." ".$row['unite'].")"; ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label>Quantité :</label>
    <input type="number" step="0.01" min="0.01" name="quantite" required>

    <label>Type de perte :</label>
    <select name="type_perte" required>
        <option value="">--Choisir--</option>
        <option value="cassé">Cassé</option>
        <option value="expiré">Expiré</option>
    </select>

    <br><br>
    <button type="submit"><i class="fa-solid fa-floppy-disk"></i> Enregistrer perte</button>
</form>

<a href="dashboard.php" class="return"><i class="fa-solid fa-arrow-left"></i> Retour</a>
</div>

</body>
</html>
