<?php
session_start();
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    $sql = "SELECT * FROM utilisateurs WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($mot_de_passe, $user['mot_de_passe'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['boutique_id'] = $user['boutique_id'];

            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Mot de passe incorrect.";
        }
    } else {
        $error = "Utilisateur introuvable.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Connexion - LIDAF-PE</title>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
* {
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter', sans-serif;
}

body {
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg,#0f172a,#1e293b);
    overflow:hidden;
}

/* Background animated glow */
body::before {
    content:'';
    position:absolute;
    width:600px;
    height:600px;
    background: radial-gradient(circle, rgba(99,102,241,0.4), transparent 70%);
    top:-200px;
    right:-200px;
    animation: pulse 6s infinite alternate;
}

@keyframes pulse {
    from {transform:scale(1);}
    to {transform:scale(1.2);}
}

/* Login Card */
.login-container {
    position:relative;
    width:380px;
    padding:40px;
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(20px);
    border-radius:20px;
    box-shadow:0 20px 60px rgba(0,0,0,0.6);
    color:white;
    animation:fadeIn 0.8s ease forwards;
}

@keyframes fadeIn {
    from {opacity:0; transform:translateY(20px);}
    to {opacity:1; transform:translateY(0);}
}

.login-container h2 {
    text-align:center;
    margin-bottom:30px;
    font-weight:600;
}

.input-group {
    position:relative;
    margin-bottom:20px;
}

.input-group i {
    position:absolute;
    left:12px;
    top:50%;
    transform:translateY(-50%);
    color:#aaa;
}

.input-group input {
    width:100%;
    padding:12px 12px 12px 40px;
    border:none;
    border-radius:10px;
    background:rgba(255,255,255,0.08);
    color:white;
    outline:none;
    transition:0.3s;
}

.input-group input:focus {
    background:rgba(255,255,255,0.15);
    box-shadow:0 0 10px rgba(99,102,241,0.6);
}

button {
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:linear-gradient(45deg,#3b82f6,#6366f1);
    color:white;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}

button:hover {
    transform:scale(1.05);
}

.error {
    background:rgba(255,0,0,0.2);
    padding:10px;
    border-radius:8px;
    margin-bottom:15px;
    text-align:center;
}
</style>
</head>

<body>

<div class="login-container">

<h2><i class="fa-solid fa-lock"></i> Connexion LIDAF-PE</h2>

<?php if (isset($error)): ?>
    <div class="error"><?php echo $error; ?></div>
<?php endif; ?>

<form method="POST">

<div class="input-group">
<i class="fa-solid fa-envelope"></i>
<input type="email" name="email" placeholder="Adresse email" required>
</div>

<div class="input-group">
<i class="fa-solid fa-key"></i>
<input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
</div>

<button type="submit">
<i class="fa-solid fa-right-to-bracket"></i> Se connecter
</button>

</form>

</div>

</body>
</html>
