<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$boutique_id = $_GET['boutique_id'] ?? null;

// Requête
if ($boutique_id) {
    $stmt = $conn->prepare("
        SELECT v.id, v.total, v.created_at, u.nom AS vendeur, b.nom AS boutique
        FROM ventes v
        JOIN utilisateurs u ON v.utilisateur_id = u.id
        JOIN boutiques b ON v.boutique_id = b.id
        WHERE v.boutique_id = ?
        ORDER BY v.created_at DESC
    ");
    $stmt->bind_param("i", $boutique_id);
} else {
    $stmt = $conn->prepare("
        SELECT v.id, v.total, v.created_at, u.nom AS vendeur, b.nom AS boutique
        FROM ventes v
        JOIN utilisateurs u ON v.utilisateur_id = u.id
        JOIN boutiques b ON v.boutique_id = b.id
        ORDER BY v.created_at DESC
    ");
}

$stmt->execute();
$result = $stmt->get_result();

// Export Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=ventes.xls");

echo "ID Vente\tBoutique\tVendeur\tTotal\tDate\n";

while($row = $result->fetch_assoc()) {
    echo $row['id'] . "\t" . $row['boutique'] . "\t" . $row['vendeur'] . "\t" . $row['total'] . "\t" . $row['created_at'] . "\n";
}
exit();
?>
