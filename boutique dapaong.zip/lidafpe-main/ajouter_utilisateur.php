<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'directeur') {
    header("Location: login.php");
    exit();
}

$result_boutiques = $conn->query("SELECT * FROM boutiques");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $boutique_id = $_POST['boutique_id'];

    $sql = "INSERT INTO utilisateurs (nom, email, mot_de_passe, role, boutique_id)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $nom, $email, $mot_de_passe, $role, $boutique_id);

    if ($stmt->execute()) {
        $success = "Utilisateur ajouté avec succès.";
    } else {
        $error = "Erreur : " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ajouter Utilisateur</title>
</head>
<body>

<h2>Ajouter un utilisateur</h2>

<?php
if (isset($success)) echo "<p style='color:green;'>$success</p>";
if (isset($error)) echo "<p style='color:red;'>$error</p>";
?>

<form method="POST">

    <label>Nom :</label><br>
    <input type="text" name="nom" required><br><br>

    <label>Email :</label><br>
    <input type="email" name="email" required><br><br>

    <label>Mot de passe :</label><br>
    <input type="password" name="mot_de_passe" required><br><br>

    <label>Rôle :</label><br>
    <select name="role" required>
        <option value="gerant">Gérant</option>
        <option value="vendeur">Vendeur</option>
    </select><br><br>

    <label>Boutique :</label><br>
    <select name="boutique_id" required>
        <?php while($row = $result_boutiques->fetch_assoc()): ?>
            <option value="<?php echo $row['id']; ?>">
                <?php echo $row['nom']; ?>
            </option>
        <?php endwhile; ?>
    </select><br><br>

    <button type="submit">Ajouter</button>

</form>

<br>
<a href="dashboard.php">Retour</a>

</body>
</html>
