<?php
session_start();
include("config.php");

// Vérification que l'utilisateur est directeur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'directeur') {
    header("Location: login.php");
    exit();
}

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = trim($_POST['nom'] ?? '');

    if ($nom) {
        $check = $conn->prepare("SELECT id FROM boutiques WHERE nom = ?");
        $check->bind_param("s", $nom);
        $check->execute();
        $check->store_result();

        if($check->num_rows > 0){
            $error = "Cette boutique existe déjà.";
        } else {
            $stmt = $conn->prepare("INSERT INTO boutiques (nom) VALUES (?)");
            $stmt->bind_param("s", $nom);
            $stmt->execute();
            $success = "Boutique ajoutée avec succès.";
        }
    } else {
        $error = "Veuillez saisir un nom de boutique.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Ajouter Boutique - LIDAF-PE</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Inter',sans-serif; background:#f5f7fa; margin:0; padding:20px; }
.card { max-width:500px; margin:auto; padding:25px; border-radius:15px; background:rgba(255,255,255,0.05); backdrop-filter: blur(10px); box-shadow:0 10px 20px rgba(0,0,0,0.2);}
h2 { color:#333; margin-bottom:20px; text-align:center; }
label { display:block; margin-top:15px; font-weight:600; }
input, button { width:100%; padding:10px; margin-top:5px; border-radius:6px; border:1px solid #ccc; font-size:14px; }
button { background:#6366f1; color:white; border:none; cursor:pointer; transition:0.3s; }
button:hover { background:#4f46e5; }
.success { background:rgba(0,255,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; text-align:center;}
.error { background:rgba(255,0,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; text-align:center;}
a.return { display:inline-block; margin-top:15px; color:#6366f1; text-decoration:none; text-align:center; }
a.return:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="card">
<h2><i class="fa-solid fa-store"></i> Ajouter une boutique</h2>

<?php if(isset($success)) echo "<div class='success'><i class='fa-solid fa-check'></i> $success</div>"; ?>
<?php if(isset($error)) echo "<div class='error'><i class='fa-solid fa-triangle-exclamation'></i> $error</div>"; ?>

<form method="POST">
    <label>Nom de la boutique :</label>
    <input type="text" name="nom" placeholder="Ex : LIDAF-PE Centre" required>
    <br><br>
    <button type="submit"><i class="fa-solid fa-plus"></i> Ajouter boutique</button>
</form>

<a href="dashboard.php" class="return"><i class="fa-solid fa-arrow-left"></i> Retour au dashboard</a>
</div>

</body>
</html>
