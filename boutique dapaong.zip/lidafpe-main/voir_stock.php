<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'gerant' && $_SESSION['role'] != 'directeur')) {
    header("Location: login.php");
    exit();
}

// Par défaut, on prend la boutique du gérant
$boutique_id = $_SESSION['boutique_id'] ?? null;

// Si directeur et qu'il a choisi une boutique
if ($_SESSION['role'] == 'directeur') {
    if (isset($_GET['boutique_id']) && is_numeric($_GET['boutique_id'])) {
        $boutique_id = intval($_GET['boutique_id']);
    } else {
        // Si aucune boutique sélectionnée, prend la première boutique disponible
        $res = $conn->query("SELECT id FROM boutiques ORDER BY id ASC LIMIT 1");
        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $boutique_id = $row['id'];
        } else {
            die("Aucune boutique disponible !");
        }
    }
}

// Vérification : boutique_id doit être défini
if (!$boutique_id) {
    die("Erreur : boutique introuvable.");
}

// Requête sécurisée avec prepared statement
$stmt = $conn->prepare("SELECT * FROM produits WHERE boutique_id = ? ORDER BY nom ASC");
$stmt->bind_param("i", $boutique_id);
$stmt->execute();
$result_produits = $stmt->get_result();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Stock - LIDAF-PE</title>
</head>
<body>

<h2>Stock de la boutique</h2>

<?php if ($_SESSION['role'] == 'directeur'): ?>
    <h4>Choisir une boutique :</h4>
    <ul>
    <?php
    $boutiques = $conn->query("SELECT * FROM boutiques");
    while($b = $boutiques->fetch_assoc()) {
        echo "<li><a href='voir_stock.php?boutique_id=".$b['id']."'>".$b['nom']."</a></li>";
    }
    ?>
    </ul>
<?php endif; ?>

<table border="1" cellpadding="5">
    <tr>
        <th>Produit</th>
        <th>Quantité</th>
        <th>Unité</th>
        <th>Prix achat</th>
        <th>Prix vente</th>
        <th>Alerte</th>
    </tr>
    <?php while($row = $result_produits->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['nom']; ?></td>
        <td><?php echo $row['quantite']; ?></td>
        <td><?php echo $row['unite']; ?></td>
        <td><?php echo $row['prix_achat']; ?></td>
        <td><?php echo $row['prix_vente']; ?></td>
        <td>
            <?php
            if ($row['quantite'] <= 5) { 
    echo "<span style='color:red;font-weight:bold;'>Stock faible !</span>";
} else {
    // Vérifier s’il y a perte expirée
    $res_perte = $conn->query("SELECT SUM(quantite) as perte_exp FROM pertes_produits WHERE produit_id=".$row['id']." AND type_perte='expiré'");
    $perte = $res_perte->fetch_assoc()['perte_exp'] ?? 0;
    if($perte > 0){
        echo "<span style='color:orange;'>Produit expiré : $perte</span>";
    } else {
        echo "-";
    }
}

            ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<br>
<a href="dashboard.php">Retour</a>

</body>
</html>
