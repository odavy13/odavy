<?php
include("config.php");

$nom = "Directeur";
$email = "admin@lidafpe.com";
$mot_de_passe = password_hash("123456", PASSWORD_DEFAULT);
$role = "directeur";

$sql = "INSERT INTO utilisateurs (nom, email, mot_de_passe, role)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nom, $email, $mot_de_passe, $role);

if ($stmt->execute()) {
    echo "Directeur créé avec succès.";
} else {
    echo "Erreur : " . $conn->error;
}
?>
