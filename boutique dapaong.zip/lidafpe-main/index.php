<?php
session_start();
include("config.php");

// Vérifier que l'utilisateur est connecté
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$nom_user = $_SESSION['nom'] ?? 'Utilisateur';
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Accueil - LIDAF-PE</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
        h1, h2, h3 { color: #333; }
        ul { margin-left: 20px; }
        .menu a { margin-right: 15px; text-decoration: none; background-color: #4CAF50; color: white; padding: 5px 10px; border-radius: 3px; }
        .guide { background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .section { margin-bottom: 20px; }
    </style>
</head>
<body>

<h1>Bienvenue sur LIDAF-PE, <?php echo htmlspecialchars($nom_user); ?> !</h1>

<div class="menu">
    <a href="dashboard.php">Dashboard</a>
    <a href="enregistrer_vente.php">Nouvelle vente</a>
    <a href="enregistrer_perte.php">Enregistrer perte</a>
    <a href="logout.php">Déconnexion</a>
</div>

<hr>

<div class="guide">

    <div class="section">
        <h2>🌟 Bienfaits du commerce</h2>
        <ul>
            <li>Le commerce favorise l'accès aux produits essentiels pour la communauté.</li>
            <li>Il contribue au développement économique local et à la création d’emplois.</li>
            <li>Il permet de maintenir des prix compétitifs et transparents pour les clients.</li>
        </ul>
    </div>

    <div class="section">
        <h2>💼 Travail attendu d’un employé</h2>
        <ul>
            <li>Respecter les horaires et être ponctuel.</li>
            <li>Maintenir le stock et l’espace de vente propres et organisés.</li>
            <li>Enregistrer toutes les ventes correctement et informer le gérant des ruptures ou pertes.</li>
            <li>Travailler en équipe et respecter les collègues et le gérant.</li>
        </ul>
    </div>

    <div class="section">
        <h2>📜 Règles qui régissent le commerce</h2>
        <ul>
            <li>Toutes les ventes doivent être correctement enregistrées dans le système.</li>
            <li>Les prix sont fixés par le directeur et ne doivent pas être modifiés sans autorisation.</li>
            <li>Les produits expirés ou cassés doivent être signalés et enregistrés.</li>
            <li>Respecter la législation locale en matière de commerce et d’hygiène.</li>
        </ul>
    </div>

    <div class="section">
        <h2>🤝 Relations client-vendeur</h2>
        <ul>
            <li>Accueillir chaque client avec courtoisie et respect.</li>
            <li>Écouter les besoins du client et proposer les produits adaptés.</li>
            <li>Fournir des informations claires sur les prix, quantités et promotions.</li>
            <li>Traiter les plaintes ou problèmes avec professionnalisme.</li>
        </ul>
    </div>

    <div class="section">
        <h2>📝 Règles de courtoisie affichées pour le client</h2>
        <ul>
            <li>Bonjour et bienvenue chez LIDAF-PE !</li>
            <li>Nous respectons chaque client et vous remercions de votre visite.</li>
            <li>Merci de nous signaler tout problème avec les produits ou le service.</li>
            <li>Nous nous engageons à vous offrir un service rapide, poli et efficace.</li>
        </ul>
    </div>

</div>

</body>
</html>
