<?php
session_start();
include("config.php");

// Vérification de connexion et rôle
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'directeur') {
    header("Location: login.php");
    exit();
}

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = trim($_POST['nom'] ?? '');
    $boutique_id = intval($_POST['boutique']);
    $quantite = floatval($_POST['quantite'] ?? 0);
    $unite = $_POST['unite'] ?? '';
    $prix_achat = floatval($_POST['prix_achat'] ?? 0);
    $prix_vente = floatval($_POST['prix_vente'] ?? 0);

    if ($nom && $boutique_id > 0 && $quantite >= 0 && in_array($unite, ['kg','litre','sac','carton']) && $prix_achat >= 0 && $prix_vente >= 0) {
        $stmt = $conn->prepare("INSERT INTO produits (nom, boutique_id, quantite, unite, prix_achat, prix_vente) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("siiddd", $nom, $boutique_id, $quantite, $unite, $prix_achat, $prix_vente);
        $stmt->execute();
        $success = "Produit ajouté avec succès.";
    } else {
        $error = "Veuillez remplir tous les champs correctement.";
    }
}

// Récupérer toutes les boutiques
$boutiques = $conn->query("SELECT * FROM boutiques ORDER BY nom ASC");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Ajouter Produit - LIDAF-PE</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Inter',sans-serif; background:#f5f7fa; margin:0; padding:20px; }
.card { max-width:600px; margin:auto; padding:25px; border-radius:15px; background:rgba(255,255,255,0.05); backdrop-filter: blur(10px); box-shadow:0 10px 20px rgba(0,0,0,0.2);}
h2 { color:#333; margin-bottom:20px; text-align:center; }
label { display:block; margin-top:15px; font-weight:600; }
input, select, button { width:100%; padding:10px; margin-top:5px; border-radius:6px; border:1px solid #ccc; font-size:14px; }
button { background:#6366f1; color:white; border:none; cursor:pointer; transition:0.3s; }
button:hover { background:#4f46e5; }
.success { background:rgba(0,255,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; text-align:center;}
.error { background:rgba(255,0,0,0.15); padding:12px; border-radius:8px; margin-bottom:15px; text-align:center;}
a.return { display:inline-block; margin-top:15px; color:#6366f1; text-decoration:none; text-align:center; }
a.return:hover { text-decoration:underline; }
</style>
</head>
<body>

<div class="card">
<h2><i class="fa-solid fa-box"></i> Ajouter un produit</h2>

<?php if(isset($success)) echo "<div class='success'><i class='fa-solid fa-check'></i> $success</div>"; ?>
<?php if(isset($error)) echo "<div class='error'><i class='fa-solid fa-triangle-exclamation'></i> $error</div>"; ?>

<form method="POST">
    <label>Nom du produit :</label>
    <input type="text" name="nom" placeholder="Ex : Riz" required>

    <label>Boutique :</label>
    <select name="boutique" required>
        <option value="">--Choisir--</option>
        <?php while($b = $boutiques->fetch_assoc()): ?>
            <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['nom']); ?></option>
        <?php endwhile; ?>
    </select>

    <label>Quantité initiale :</label>
    <input type="number" step="0.01" name="quantite" min="0" required>

    <label>Unité :</label>
    <select name="unite" required>
        <option value="">--Choisir--</option>
        <option value="kg">Kg</option>
        <option value="litre">Litre</option>
        <option value="sac">Sac</option>
        <option value="carton">Carton</option>
    </select>

    <label>Prix d'achat :</label>
    <input type="number" step="0.01" name="prix_achat" min="0" required>

    <label>Prix de vente :</label>
    <input type="number" step="0.01" name="prix_vente" min="0" required>

    <br><br>
    <button type="submit"><i class="fa-solid fa-plus"></i> Ajouter produit</button>
</form>

<a href="dashboard.php" class="return"><i class="fa-solid fa-arrow-left"></i> Retour au dashboard</a>
</div>

</body>
</html>
